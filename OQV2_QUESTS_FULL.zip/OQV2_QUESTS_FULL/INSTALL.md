# OQV2 QUESTS — Full Package

**Origen Quest V2 inspired · Unlimited Mission System for FiveM**
ESX · ox_lib · ox_inventory · ox_target · oxmysql

> Author: **Codex Dev: #Alesh48 5654**
> *Made with CodeX Dev.*

---

## What is in this archive

| Path | What it is | Needed on your server? |
|------|------------|------------------------|
| `oqv2_quests/` | **The resource.** Drop this folder into `resources/[custom]/`. | ✅ **Yes — this is the script** |
| `oqv2_quests-resource-only.zip` | The same folder zipped on its own, with the dev-only preview files stripped out. Use it if you upload resources as archives. | Alternative to the above |
| `_dev/tools/` | The automated test suite used to validate this build. | ❌ No — development only |
| `_dev/package.json` | npm dependencies for those tools. | ❌ No — development only |
| `INSTALL.md` | This file. | ❌ No |

> **Only the `oqv2_quests` folder goes on your server.** `_dev/` is not a FiveM resource
> and will not start.

---

## Quick install (3 steps)

### 1. Copy the resource

```
resources/[custom]/oqv2_quests
```

The folder must be named exactly `oqv2_quests` and `fxmanifest.lua` must sit at its root.
A common mistake is ending up with `oqv2_quests/oqv2_quests/fxmanifest.lua` — that will not start.

### 2. Import the database

```bash
mysql -u root -p your_database < oqv2_quests/sql/oqv2_quests.sql
```

**Optional** — the resource creates its seven tables automatically on first boot and migrates
them on later updates. Importing manually is just faster and lets you review the schema.

### 3. Add it to `server.cfg`

Order matters — it must come after its dependencies:

```cfg
ensure oxmysql
ensure ox_lib
ensure ox_inventory
ensure ox_target
ensure es_extended

ensure oqv2_quests

# grant your admin group access to the /oqv2 panel
add_ace group.admin oqv2.admin allow
```

Restart. You should see:

```
[OQV2] database schema ready
[OQV2] loaded 4 missions / 4 locations / 2 hostile groups
```

---

## Items

The example missions and hostile groups reference these. Add the first three to
`ox_inventory/data/items.lua` (or delete the examples and build your own in the panel):

```lua
['scrapmetal']     = { label = 'Scrap Metal',     weight = 800,  stack = true, close = true },
['sealed_package'] = { label = 'Sealed Package',  weight = 1200, stack = true, close = true },
['evidence_bag']   = { label = 'Evidence Bag',    weight = 500,  stack = true, close = true },
```

`water`, `bandage` and `weapon_ammo` ship with ox_inventory already.

---

## First run

| Command | Who | What it does |
|---------|-----|--------------|
| `/oqv2` | **admins only** | Opens the admin panel — build missions, locations and hostile NPCs in-game |
| `/quests` or **F7** | everyone | Player journal: missions, discovered-locations map, progress |
| `/oqv2abandon` | everyone | Abandon the active mission |
| `/oqv2xp <id> <n>` | admins | Grant XP |
| `oqv2 reload` / `oqv2 stats` | console | Reload data / print a summary |

**If `/oqv2` says you have no permission**, use any one of these
(`oqv2_quests/config/config.lua` → `Config.Admin`):

- `add_ace group.admin oqv2.admin allow` in `server.cfg`, **or**
- put your ESX group in `Config.Admin.groups`, **or**
- add your license to `Config.Admin.identifiers`, e.g. `'license:0000…'`

---

## The 8 modules

| # | Module | Responsibility |
|---|--------|----------------|
| 1 | Core & framework bridge | ESX bootstrap, identifiers, money, inventory, notifications, permissions, rate limiting |
| 2 | Database layer | oxmysql schema + auto-migrations, CRUD, progress, discovery, audit logs, leaderboard |
| 3 | Schema & validation | Normalises every entity, coerces types, rejects circular prerequisite chains |
| 4 | Progression | XP curve, levels, level rewards, rolling cooldown windows, discovery |
| 5 | Mission runtime | 8 objective types, server-side distance/item/money checks, restrictions, payouts |
| 6 | Evil NPC system | Hostile groups, companions, weapons, difficulty, proximity spawn, loot, police dispatch |
| 7 | Admin NUI | 8 pages: dashboard, missions, locations, hostiles, quest tree, players, logs, settings |
| 8 | Player experience | Journal, map, live objective tracker HUD, XP and level-up toasts |

Full documentation — every config key, export, event and a troubleshooting table — is in
**`oqv2_quests/README.md`**.

---

## Verification (optional, for developers)

This build shipped only after four checks passed. Node.js 18+ required:

```bash
cd _dev
npm install        # luaparse, jsdom, fengari
npm test           # runs all four suites
```

Individually:

```bash
npm run lint       # Lua syntax     → 22 files, 0 errors
npm run analyze    # static analysis → clean
npm run test:lua   # Lua runtime    → 70/70 passing
npm run test:nui   # NUI / DOM      → 64/64 passing
```

| Suite | What it covers | Result |
|-------|----------------|--------|
| `lualint.js` | Every `.lua` file parsed as Lua 5.3 | **22 files, 0 errors** |
| `analyze.js` | Undefined `OQ.*` calls, net events without handlers, ox_lib callbacks awaited without a register, NUI callbacks without a handler | **clean** |
| `lua-run.js` | A real Lua VM with mocked FiveM/ESX/ox natives: boot, permissions, mission lifecycle, cooldowns, restrictions, schedules, hostile NPCs, loot caps, admin CRUD, import/export, rate limiter | **70 / 70** |
| `nui-test.js` | Headless DOM: all 8 admin pages, every editor tab, list add/remove, chip toggles, draft commit, journal, HUD, 24 icons | **64 / 64** |

### Previewing the UI in a browser

The NUI is plain HTML/CSS/JS with no build step, so it runs outside the game:

```bash
cd _dev
npm run preview          # or: python3 -m http.server 3000 --directory ../oqv2_quests/web
```

Then open:

- `http://localhost:3000/dev.html?view=admin` — the admin panel with mock data
- `http://localhost:3000/dev.html?view=journal` — the player journal
- `http://localhost:3000/dev.html?hud=1` — the objective tracker HUD

`dev.html` and `web/dev/mock.js` are **not** listed in `fxmanifest.lua`, so they are never sent to
players — they exist purely for offline design work, and they are absent from
`oqv2_quests-resource-only.zip`.

---

## Requirements

| Dependency | Notes |
|------------|-------|
| es_extended | ESX Legacy 1.9+ |
| ox_lib | callbacks, notifications, context menus, progress bars, dialogs |
| ox_inventory | item checks, removal, granting, carry weight |
| ox_target | interaction with givers and corpses |
| oxmysql | persistence |

FiveM artifacts **6683+** (the manifest enables Lua 5.4 and `fxv2_oal`).

---

## Credits

**Codex Dev: #Alesh48 5654**
*Made with CodeX Dev.*

Design inspired by Origen Quest V2. Built for ESX with ox_lib, ox_inventory, ox_target and oxmysql.
